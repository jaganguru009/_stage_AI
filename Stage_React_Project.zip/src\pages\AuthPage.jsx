import { Link } from 'react-router-dom'
import { StageButton } from '../components/stage/StageButton'

export function AuthPage({ mode }) {
  const isLogin = mode === 'login'
  return <main className="auth-page"><Link to="/" className="auth-brand">stage<span>.</span></Link><section className="auth-card"><p className="workspace-kicker">WELCOME TO STAGE</p><h1>{isLogin ? 'Welcome back.' : 'Start your next chapter.'}</h1><p>{isLogin ? 'Sign in to your creative workspace.' : 'Build the professional home for your work.'}</p><form onSubmit={(event) => event.preventDefault()}><label>Email address<input type="email" placeholder="you@example.com" /></label><label>Password<input type="password" placeholder="••••••••" /></label><StageButton type="submit">{isLogin ? 'Sign in' : 'Create account'} <span>→</span></StageButton></form><small>{isLogin ? 'New to Stage?' : 'Already have an account?'} <Link to={isLogin ? '/register' : '/login'}>{isLogin ? 'Create your profile' : 'Sign in'}</Link></small></section></main>
}
